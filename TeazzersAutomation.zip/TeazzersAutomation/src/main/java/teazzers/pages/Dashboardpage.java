package teazzers.pages;

import org.openqa.selenium.chrome.ChromeDriver;

import teazzers.api.ProjSpecificMethods;

public class Dashboardpage extends ProjSpecificMethods {
	public Dashboardpage(ChromeDriver driver) {
		this.driver=driver;	
		
		}
	
		public Dashboardpage verifypagetitle() {
			String gettitle = driver.getTitle();
			//System.out.println(pagetitle);
			String pagetitle = "TeaWorld - Dashboard";
			if(pagetitle.equalsIgnoreCase(gettitle)) {
				System.out.println("title of the page is verified");
			}
			else {
				System.out.println("title of the page is not verified");
			}
			return this;
		}

		public Dashboardpage clickUsername() throws InterruptedException {
			Thread.sleep(2000);
			driver.findElementByXPath(prop.getProperty("dashboard.clkusername.xpath")).click();
			return this;
		}
		
		public LoginPage clickLogOut() {
			driver.findElementByXPath(prop.getProperty("dashboard.clklogout.xpath")).click();
			return new LoginPage(driver);
		}
		
		public ManageParentCompaniespage clickPartners() {
			driver.findElementByXPath(prop.getProperty("dashboard.clkpartners.xpath")).click();
			return new ManageParentCompaniespage(driver);
		}
		
		public ManageTabletspage clickSmartBrew() {
			driver.findElementByXPath(prop.getProperty("dashboard.clksmartbrew.xpath")).click();
			return new ManageTabletspage();
		}
		
		public InstallationManagementpage clickInstall() {
			driver.findElementByXPath(prop.getProperty("dashboard.clkinstall.xpath")).click();
			return new InstallationManagementpage();
		}
		
}
