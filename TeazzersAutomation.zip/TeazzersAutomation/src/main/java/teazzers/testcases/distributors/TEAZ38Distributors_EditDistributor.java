package teazzers.testcases.distributors;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import teazzers.api.ProjSpecificMethods;
import teazzers.pages.EditDistributorpage;
import teazzers.pages.EditParentCompanypage;
import teazzers.pages.LoginPage;
import teazzers.pages.ManageParentCompaniespage;

public class TEAZ38Distributors_EditDistributor extends ProjSpecificMethods {
	@BeforeTest
	public void setecelfile() {
		testCaseName = "Edit Distributor Record";
		testCaseDescription = "Editing the Distributor record and verifying the changes are updated";
		author = "Suganya";
		excelfile="TEAZ038_Distri_EditDistribtr";
	}
	@Test(dataProvider = "getdata")
	public void editDistributor(String url,String uName, String Pwd, String searchname,String vendorname, String phone ,String parentname) throws InterruptedException {
		new LoginPage(driver,eachNode).launchURL(url).enterUsername(uName).enterPassword(Pwd).clickLogin().clickPartners().clickDistributors();
		new ManageParentCompaniespage(driver, eachNode).enterSearchKeyword(searchname).clickSearchIcon().clickReqRec(searchname).enterPhoneNum(phone);
		new EditDistributorpage(driver, eachNode).enterVendorNum(vendorname).clickParentName().enterParentname(parentname).clickSearchParnticon().clickfirstParentrec();
		new EditParentCompanypage(driver, eachNode).clickUpdateBtn().clickParentCompaniesTab().clickDistributors();
		new ManageParentCompaniespage(driver, eachNode).enterSearchKeyword(searchname).clickSearchIcon();
		
}

}
