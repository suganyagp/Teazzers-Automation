package teazzers.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import teazzers.api.ProjSpecificMethods;
import teazzers.pages.LoginPage;

public class TEAZ09_EditParentWitDetails extends ProjSpecificMethods
{
	@BeforeTest
	public void setecelfile() {
		excelfile="TEAZ009_EditParentWitDetails";
	}
	@Test(dataProvider = "getdata")
	public void editParentCompany(String url,String uName, String Pwd, String searchname,String tradename, String phone) throws InterruptedException {
		new LoginPage(driver).launchURL(url).enterUsername(uName).enterPassword(Pwd).clickLogin().verifypagetitle().clickPartners().
		enterSearchKeyword(searchname).clickSearchIcon().clickSearchFirstRec().enterTradeName(tradename).enterPhoneNum(phone).
		clickUpdateBtn().clickParentCompaniesTab().enterSearchKeyword(searchname).clickSearchIcon();
		
}
	
}
