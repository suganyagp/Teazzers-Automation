package teazzers.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import teazzers.api.ProjSpecificMethods;

public class EditParentCompanypage extends ProjSpecificMethods {
	
	public EditParentCompanypage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public ManageParentCompaniespage clickParentCompaniesTab() {
		driver.findElementByXPath(prop.getProperty("editparntcmpy.clkparntcmpy.xpath")).click();
		return new ManageParentCompaniespage(driver);
	}
	
	public EditParentCompanypage enterTradeName(String tradenme ) {
		driver.findElementById(prop.getProperty("editparntcmpy.entrtradename.id")).sendKeys(tradenme);
		return this;
	}
	public EditParentCompanypage enterPhoneNum(String phne) {
		driver.findElementById(prop.getProperty("editparntcmpy.entrphone.id")).sendKeys(phne);
		return this;
		
	}
	
	public EditParentCompanypage clickUpdateBtn() {
		driver.findElement(By.xpath(prop.getProperty("editparntcmpy.clkupdate.xpath"))).click();
		return this;
	}
	
	public EditParentCompanypage clickCreateUnderAddress() {
		driver.findElement(By.id(prop.getProperty("editparntcmpy.clkcreateaddr.id"))).click();
		return this;
	}
	
	public EditParentCompanypage clickAddressdrpdwnBilling() {
		WebElement addr = driver.findElementById(prop.getProperty("editparntcmpy.seldrpwn.id"));
		Select drpdwn = new Select(addr);
		drpdwn.selectByVisibleText("Physical Address");
		return this;
		
	}
	
	public EditParentCompanypage enterAddressLine1(String addressline) {
		driver.findElementById(prop.getProperty("editparntcmpy.entraddr.id")).sendKeys(addressline);
		return this;
	}
	
	public EditParentCompanypage enterCity(String city) {
		driver.findElementById(prop.getProperty("editparntcmpy.entrcity.id")).sendKeys(city);
		return this;
	}
	
	public EditParentCompanypage enterState(String state) {
		driver.findElementById(prop.getProperty("editparntcmpy.entrstate.id")).sendKeys(state);
		return this;
	}

	public EditParentCompanypage enterZipcode(String zipcode) {
		driver.findElementById(prop.getProperty("editparntcmpy.enterzip.id")).sendKeys(zipcode);
		return this;
	}
	
	public EditParentCompanypage clickSaveChangesBtn() {
		driver.findElementByName(prop.getProperty("editparntcmpy.savechanges.name")).click();
		return this;
	}
	
	
}
