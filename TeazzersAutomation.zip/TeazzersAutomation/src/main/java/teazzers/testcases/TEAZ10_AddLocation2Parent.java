package teazzers.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import teazzers.api.ProjSpecificMethods;
import teazzers.pages.LoginPage;

public class TEAZ10_AddLocation2Parent extends ProjSpecificMethods {
	@BeforeTest
	public void setecelfile() {
		excelfile="TEAZ010_AddLocation2Parent";
	}
	@Test(dataProvider = "getdata")
	public void editParentCompany(String url,String uName, String Pwd, String searchname,String addressline1, String city, String state, String zipcode) throws InterruptedException {
		new LoginPage(driver).launchURL(url).enterUsername(uName).enterPassword(Pwd).clickLogin().verifypagetitle().clickPartners().
		enterSearchKeyword(searchname).clickSearchIcon().clickSearchFirstRec().clickCreateUnderAddress().clickAddressdrpdwnBilling().enterAddressLine1(addressline1)
		.enterCity(city).enterState(state).enterZipcode(zipcode).clickSaveChangesBtn();
		
}

}
