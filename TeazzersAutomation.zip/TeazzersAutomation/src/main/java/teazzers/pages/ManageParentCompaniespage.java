package teazzers.pages;



import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import teazzers.api.ProjSpecificMethods;

public class ManageParentCompaniespage extends ProjSpecificMethods {
	
	public ManageParentCompaniespage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public ManageParentCompaniespage getItemsCount() {
		 String get_Items_Count = driver.findElementByXPath(prop.getProperty("ManageParntCmpy.itemscount.xpath")).getText();
		System.out.println("Items displayed are:"+get_Items_Count);
		return this;
	
	}
	
	public EditParentCompanypage clickFirstRecInNameColumn() {
		driver.findElementByXPath(prop.getProperty("ManageParntCmpy.frstrecinname.xpath")).click();
		return new EditParentCompanypage(driver);
	}
	
	public ManageParentCompaniespage enterSearchKeyword(String searchnme) {
		driver.findElementByName(prop.getProperty("ManageParntCmpy.enteresearch.name")).sendKeys(searchnme);
		return this;
	}
	
	public ManageParentCompaniespage clickSearchIcon() {
		driver.findElementByXPath(prop.getProperty("ManageParntCmpy.clksearch.xpath")).click();
		return this;
	}
	
	public AddNewParentCompanyPage clickAddbtn() {
		driver.findElementById(prop.getProperty("ManageParntCmpy.clkaddbtn.id")).click();
		return new AddNewParentCompanyPage(driver);
	}
	
	public EditParentCompanypage clickSearchFirstRec() {
		driver.findElement(By.xpath(prop.getProperty("ManageParntCmpy.clkfrstsearchrec.xpath"))).click();
		return new EditParentCompanypage(driver);
	}
	
	

}
