package teazzers.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcel {
	public void writeExcel(String fileName, String searval) throws IOException {
		 FileInputStream inputStream = new FileInputStream(new File("./data/"+fileName+".xlsx"));
		 XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
		 XSSFSheet sheet = workbook.getSheet("Sheet1");
		 XSSFRow row = null;
		 XSSFCell cell = null;
		 XSSFRow row2 = null;
		 XSSFCell cell2 = null;
		 int colNum= -1;
		 int colNum2 =-1;
		 row=sheet.getRow(0);
		 for (int i = 0; i<row.getLastCellNum(); i++) {
			if(row.getCell(i).getStringCellValue().trim().equals("Timestamp")) {
				colNum=i;
			}
			
		}
		 row=sheet.getRow(1);
		 if (row != null) {
			 cell = row.getCell(colNum);
			
		}
		if (cell != null) {
			cell.setCellValue(searval);
		}
		 /*row2=sheet.getRow(0);
		 for (int j = 0; j<row2.getLastCellNum(); j++) {
				if(row2.getCell(j).getStringCellValue().trim().equals("UniqueNum")) {
					colNum2=j;
				}
				
			}
		 row2=sheet.getRow(1);
		 if (row2 != null) {
			 cell2 = row2.getCell(colNum2);
			
		}
		 
		 if (cell2 != null) {
				cell2.setCellValue(unique);
			}
*/	 
		    inputStream.close();

	         FileOutputStream outputStream = new FileOutputStream("./data/"+fileName+".xlsx");
	         workbook.write(outputStream);
	         workbook.close();
	         outputStream.close();

	

        

		
		
		
		
		
	}
	
}