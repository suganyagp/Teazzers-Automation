package teazzers.pages;

public class ManageTabletspage {

}
