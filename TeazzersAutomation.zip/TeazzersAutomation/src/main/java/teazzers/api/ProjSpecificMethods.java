package teazzers.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import teazzers.util.ReadExcel;

public class ProjSpecificMethods {
	public static ChromeDriver driver;
	public String excelfile;
	public static Properties prop;
	
	@BeforeSuite
	public void loadObj() {
		prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("C:\\Users\\suganyap\\Desktop\\Automation\\Teazzers\\TeazzersAutomation\\ObjectRepo\\object.properties")));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@AfterSuite
	public void unloadObjects() {
		prop = null;
	}


	@BeforeMethod
	public void login(){
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\suganyap\\Desktop\\Automation\\Teazzers\\TeazzersAutomation\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
	}

	@AfterMethod
	public void closeBrowser() {
		driver.close();
	}
	
	
	@DataProvider
	public String[][] getdata() throws IOException {
		ReadExcel obj= new ReadExcel();
		String[][] readexcel = obj.readExcel(excelfile);
		return readexcel;
		
		
		
		
	}

}
