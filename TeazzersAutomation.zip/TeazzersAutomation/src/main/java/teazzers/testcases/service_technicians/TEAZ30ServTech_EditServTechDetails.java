package teazzers.testcases.service_technicians;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import teazzers.api.ProjSpecificMethods;
import teazzers.pages.LoginPage;
import teazzers.pages.ManageParentCompaniespage;

public class TEAZ30ServTech_EditServTechDetails extends ProjSpecificMethods {
	@BeforeTest
	public void setecelfile() {
		testCaseName = "Edit Service Technician Record";
		testCaseDescription = "Editing the Service Technician record and verifying the changes are updated";
		author = "Suganya";
		excelfile="TEAZ009_EditParentWitDetails";
	}
	@Test(dataProvider = "getdata")
	public void editServTechn(String url,String uName, String Pwd, String searchname,String tradename, String phone) throws InterruptedException {
		new LoginPage(driver,eachNode).launchURL(url).enterUsername(uName).enterPassword(Pwd).clickLogin().clickPartners().clickServiceTechn();
		new ManageParentCompaniespage(driver, eachNode).enterSearchKeyword(searchname).clickSearchIcon().clickReqRec(searchname).enterTradeName(tradename).enterPhoneNum(phone).
		clickUpdateBtn().clickParentCompaniesTab().clickServiceTechn();
		new ManageParentCompaniespage(driver, eachNode).enterSearchKeyword(searchname).clickSearchIcon();
		
}

}
