package teazzers.pages;

import org.openqa.selenium.chrome.ChromeDriver;

import teazzers.api.ProjSpecificMethods;

public class LoginPage extends ProjSpecificMethods {
	public LoginPage(ChromeDriver driver) {
		this.driver=driver;	
		
	}
	public LoginPage launchURL(String url) {
		driver.get(url);
		return this;
	}
	 public LoginPage enterUsername(String usrname) {
		 driver.findElementById(prop.getProperty("login.username.id")).sendKeys(usrname);
		 return this;
	 }
	 public LoginPage enterPassword(String pwd) {
		 driver.findElementById(prop.getProperty("login.password.id")).sendKeys(pwd);
		 return this;
	 }
	 public Dashboardpage clickLogin() {
		 driver.findElementByXPath(prop.getProperty("login.loginbtn.xpath")).click();
		 return new Dashboardpage(driver);
	 }

}
