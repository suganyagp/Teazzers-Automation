package teazzers.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import teazzers.api.ProjSpecificMethods;
import teazzers.pages.LoginPage;

public class TEAZ01_VerifyGrid extends ProjSpecificMethods {
	@BeforeTest
	public void setecelfile() {
		excelfile="TC001_Login";
	}
	@Test(dataProvider = "getdata")
	public void verifyGrid(String url,String uName, String Pwd) throws InterruptedException {
		new LoginPage(driver).launchURL(url).enterUsername(uName).enterPassword(Pwd).clickLogin().verifypagetitle().clickPartners(). getItemsCount().clickFirstRecInNameColumn().clickParentCompaniesTab();
	}

}
