package teazzers.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import teazzers.api.ProjSpecificMethods;

public class AddNewParentCompanyPage extends ProjSpecificMethods {
	

	public AddNewParentCompanyPage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public AddNewParentCompanyPage enterName(String name) {
		driver.findElementById(prop.getProperty("addnewparntcmpy.entrname.id")).sendKeys(name);
		return this;
	}
	
	public AddNewParentCompanyPage unCheckOwnerOperator() {
		driver.findElement(By.xpath(prop.getProperty("addnewparntcmpy.uncheckowner.xpath"))).click();
		return this;
	}
	
	public EditParentCompanypage clickSaveBtn() {
		driver.findElement(By.xpath(prop.getProperty("addnewparntcmpy.clksave.xpath"))).click();
		return new EditParentCompanypage(driver);
	}

}
