package teazzers.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import teazzers.api.ProjSpecificMethods;
import teazzers.pages.LoginPage;

public class TEAZ07_SearchbyPhoneNum extends ProjSpecificMethods {
	@BeforeTest
	public void setecelfile() {
		excelfile="TEAZ007_SearchbyPhoneNum";
	}
	@Test(dataProvider = "getdata")
	public void searchPhoneNum(String url,String uName, String Pwd,String searchname) throws InterruptedException {
		new LoginPage(driver).launchURL(url).enterUsername(uName).enterPassword(Pwd).clickLogin().verifypagetitle().clickPartners(). 
		enterSearchKeyword(searchname).clickSearchIcon();
	}

}
